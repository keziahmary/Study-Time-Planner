package com.example.studytime.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.studytime.viewmodel.TaskViewModel
import com.example.studytime.data.Task

@Composable
fun HomeScreen(
    viewModel: TaskViewModel,
    onAddClick: () -> Unit
) {
    // Collect task list as state
    val taskList by viewModel.allTasks.collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "My Tasks",
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(taskList) { task ->
                TaskItem(task = task, onDelete = {
                    viewModel.deleteTask(task)
                })
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = onAddClick) {
            Text(text = "Add Task")
        }
    }
}

