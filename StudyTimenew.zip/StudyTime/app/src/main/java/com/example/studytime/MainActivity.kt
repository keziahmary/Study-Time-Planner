package com.example.studytime

import android.os.Bundle
import com.example.studytime.ui.LoginScreen
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.activity.viewModels
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.studytime.ui.AddTaskScreen
import com.example.studytime.ui.HomeScreen
import com.example.studytime.viewmodel.TaskViewModel

class MainActivity : ComponentActivity() {
    private val taskViewModel: TaskViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StudyTimeApp(taskViewModel)
        }
    }
}

@Composable
fun StudyTimeApp(viewModel: TaskViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate("home") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }

        composable("home") {
            HomeScreen(
                viewModel = viewModel,
                onAddClick = {
                    navController.navigate("addTask")
                }
            )
        }

        composable("addTask") {
            AddTaskScreen(
                viewModel = viewModel,
                onSave = {
                    navController.popBackStack()
                }
            )
        }
    }
}




